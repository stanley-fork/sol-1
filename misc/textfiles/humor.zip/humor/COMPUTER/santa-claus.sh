Article 28479 of alt.folklore.computers:
Path: samba!concert!rutgers!usc!zaphod.mps.ohio-state.edu!caen!spool.mu.edu!agate!rsoft!mindlink!a218
From: Charlie_Gibbs@mindlink.bc.ca (Charlie Gibbs)
Newsgroups: alt.folklore.computers
Subject: Story-telling in computer languages (was Re: Add One to COBO
Message-ID: <16006@mindlink.bc.ca>
Date: 5 Oct 92 06:23:42 GMT
Organization: MIND LINK! - British Columbia, Canada
Lines: 38

In article <6311@m1.cs.man.ac.uk> mshute@cs.man.ac.uk (Malcolm Shute)
writes:

>About 9 years ago (sorry) I posted a translation of "I'm dreaming of a white
>Christmas" into Pascal.  It was a bit clumsy... but it triggered someone
into
>responding with an absolute masterpiece of "Santa Claus is coming to town"
>translated into Unix Shell Script.  Unfortunately, I inadvertently deleted
>it some years ago.
>
>If anyone can remember it... and even better, if they can supply a copy
>to me, or to this group... I would be enormously grateful.

     It goes a lot like this:

better watchout
better !cry
better !pout
lpr why
santaclaus <northpole >town

cat >list /etc/passwd
ncheck list
ncheck list
grep >nogiftlist naughty list
grep >giftlist nice list
santaclaus <northpole >town

who | grep sleeping
who | grep awake
who | grep bad|good
for (goodness sake) {be good}

     Now if you could repost your Pascal version of "I'm Dreaming
of a White Christmas" I'd be very grateful; I wasn't on the net then.

Charlie_Gibbs@mindlink.bc.ca
"I'm cursed with hair from HELL!"  -- Night Court


