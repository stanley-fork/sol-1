===============================================================================
           Taito's OPERATION WOLF -- 'BUSTED' 09/15/1989 by THE FiRM
===============================================================================

  OPERATION WOLF is the great new arcade hit where you are a One-Man-Army,
ala RAMBO or COMMANDO, pitted against hundreds of Terrorists in an effort to
rescue their hostages.  This version supports various video-cards, joystick/
mouse/keyboard operation, and features many sound modes including TandySound
and CMS midi-cards.

  The big problem is another 'original key diskette' copy-protection scheme...
Oh, well, they give me something to do besides sleep at night...  However, the
'crack' was the easy part... (SUPER_LOCK my behind!)  The hard part was fixing
a few 'bugs' that skimmed-past their beta-testers. (Like their startup program
not correctly storing the current drive, which made it always want to go to
drive A: (since it was zero) to reset the current directory.  And their really
'strange' way of processing parameters which wouldn't handle a "R"eset-devices
option correctly if a capital "R" was used instead of a lower-case "r".)  Well,
I fixed all I could, but someone will still have to explain the 'pig-latin' the
President uses when you only save 4 of the hostages...  To wit; "WELL DONE!
I HOPE YOU TO DO YOUR NEXT MISSION JUST AS WELL";  kinda strange, eh folks???

  To get an ideal of how the game is played, don't press any keys during the
title-screen sequence and you'll go into 'demo-mode'...  Remember, your mission
is to *rescue* the hostages, so don't shoot them!  Also, the POW's in the
CONCENTRATION-CAMP mission are the main objective and they are always followed
by a Terrorist with a knife.  You *must* kill the Terrorist *before* he knifes
the POW.  If you see an angel, you missed...

  Well, since this is a difficult game to score very well in, I also decided
to add some very-special "FiRMHELP" options to aid in your rescue attempts...
These are added/removed at any time during the combat scenes by pressing
the <FN-10> key!  (This key was originally used as their "Return-to-DOS" key,
but I felt it was too easy to hit by accident!  So I altered it's use to
invoke the "FiRMHELP" mode...  Now you use the key-combination <CTRL><Q> to
"Return-to-DOS"...)


         The special-keys and modes associated with "FiRMHELP" are:
     ==================================================================

           <FN-10> --  Toggles "FiRMHELP" mode ON/OFF

            (The following are active only when "FiRMHELP" is ON)

           <FN-7>  --  Instantly improves health 5 points, adds 1
                       rocket-grenade, and 1 ammo-cartridge.

           <FN-8>  --  Instantly destroys all remaining Terrorist.
                       Usefull for skipping scenaros.  NOTE: Some
                       missions have a 'boss' scenaro at the end of
                       the mission.  He can be skipped as well...

           <FN-9>  --  "FiRM_PROTECTION" toggle.  This makes you
                       100% bullet-proof!!!


           In addition, the following keys function as follows:
     ==================================================================

           <FN-1>  --  Pause-mode toggle ON/OFF.

           <FN-2>  --  Music toggle ON/OFF.

           <FN-3>  --  Sound-effects toggle ON/OFF.

           <FN-4>  --  Changes CGA palette - see "READ.ME" file for info.


  The normal game-play keys can be redefined to your choice during the setup
screen, or use a joystick/mouse with left-button == fire gun and right-button
== fire rocket-grenade.  If you ever wish to reset the default video-mode,
joystick/mouse/keyboard, or sound modes, use "OPWOLF R" to start.  If you like
command-line options in general, use "OPWOLF ?" for a list of what's available.


  Enjoy!  (And don't cheat too much!)


      *****************************************************************
      *  >>>>>>>>>>>>>  S P E C I A L    T H A N K S !  <<<<<<<<<<<<  *
      *****************************************************************
      *  If you liked the new loader screen (and how could you not?)  * 
      *  then applaud the vast talents of LORD IRONWOLFFE!  While I   *
      *  added a few 'special-effects', the fantastic artwork itself  *
      *  was donated by he and exceded my wildest expectations! - SS  *
      *****************************************************************
                 *  FiRM greetings to crackers everywhere!  *
                 ********************************************



                           ����������������������Ŀ
                           � The Software Surgeon �
                           ������������������������
                              -=� THE FiRM ��=-
                                 ������������
                        
